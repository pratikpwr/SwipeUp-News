import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: <Widget>[
          SizedBox(
            height: 30,
          ),
          Row(
            children: <Widget>[
              IconButton(icon: Icon(Icons.menu), onPressed: () {}),
              SizedBox(
                width: 20,
              ),
              Row(
                children: <Widget>[
                  Text(
                    'SwipeUp',
                    style: TextStyle(fontSize: 22),
                  ),
                  Text(
                    'News',
                    style: TextStyle(color: Colors.blue, fontSize: 22),
                  )
                ],
              )
            ],
          )
        ],
      ),
    );
  }
}
